<?php
/**
 * Copyright © Bluethink, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Bluethink\AdvanceReports\Block\Adminhtml\Sales;

use Magento\Backend\Block\Widget\Grid\Extended;
//use Bluethink\AdvanceReports\Block\Adminhtml\Sales\Grid\AbstractGrid;
use Magento\Framework\App\ObjectManager;
use Magento\Sales\Model\Order\ConfigFactory;

class Grid extends Extended
{
    protected \Magento\Sales\Model\OrderFactory $orderFactory;

    /**
     * @var \Magento\Framework\Module\Manager
     */
    protected $moduleManager;

    protected $_backendHelper;

    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Backend\Helper\Data $backendHelper
     * @param \Magento\Sales\Model\OrderFactory $orderFactory
     * @param \Magento\Framework\Module\Manager $moduleManager
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Backend\Helper\Data $backendHelper,
//        \Bluethink\AdvanceReports\Model\ResourceModel\Sales\CollectionFactory $orderFactory,
        \Magento\Sales\Model\OrderFactory $orderFactory,
        \Magento\Framework\Module\Manager $moduleManager,
        array $data = [],
        ConfigFactory $configFactory = null
    ) {
        $this->orderFactory = $orderFactory;
        $this->moduleManager = $moduleManager;
        $this->_backendHelper = $backendHelper;
        $this->configFactory = $configFactory ?: ObjectManager::getInstance()->get(ConfigFactory::class);
        parent::__construct($context, $backendHelper, $data);
    }

    /**
     * Payment method factory
     *
     * @var \Magento\Payment\Model\Method\Factory
     */
    protected $_paymentMethodFactory;

    /**
     * @return void
     */
    protected function _construct()
    {
        parent::_construct();
        $this->setId('salesGrid');
        $this->setUseAjax(false);
    }

    public function getSearchButtonHtml()
    {
        return '';
    }
    public function getResetFilterButtonHtml()
    {
        return '';
    }

    /**
     * {@inheritdoc}
     */
    public function getResourceCollectionName()
    {
        return 'Bluethink\AdvanceReports\Model\ResourceModel\Sales\Collection';
    }

    /**
     * @return $this
     */
    protected function _prepareCollection()
    {
        $now = new \DateTime();
        $filterData = $this->getData('filter_data');
        print_r($filterData);

        $collection = $this->orderFactory->create()->getCollection();

//        if (isset($filterData) && $filterData!= null) {
//            $startDate = $now->format(date("Y-m-d", strtotime($filterData['from'])) . ' H:i:s'); // start date
//            $endDate = $now->format(date("Y-m-d", strtotime($filterData['to'])) . ' H:i:s'); // end date
//
//            $collection = $this->orderFactory->create()->addFieldToSelect(['*'])
//                ->addFieldToFilter('created_at', ['lteq' => $endDate])->addFieldToFilter('created_at', ['gteq' => $startDate]);
//
        ////            echo "<pre>";
        ////            print_r($collection->getData());
//        }
        $this->setCollection($collection);

        parent::_prepareCollection();
        return $this;
    }

    /**
     * @return $this
     */
    protected function _prepareColumns()
    {
        $this->addColumn(
            'entity_id',
            [
                'header' => __('Entity ID'),
                'index' => 'entity_id'
            ]
        );

        $this->addColumn(
            'increment_id',
            [
                'header' => __('Increment ID'),
                'index' => 'increment_id'
            ]
        );

        $this->addColumn(
            'period',
            [
                'header' => __('Interval'),
                'index' => 'period',
                'sortable' => false,
                'period_type' => $this->getPeriodType(),
                'renderer' => \Magento\Backend\Block\Widget\Grid\Column\Renderer\Date::class,
                'totals_label' => __('Total'),
                'html_decorators' => ['nobr'],
                'header_css_class' => 'col-period',
                'column_css_class' => 'col-period'
            ]
        );

        $this->addColumn(
            'orders_count',
            [
                'header' => __('Orders'),
                'index' => 'order_count',
                'type' => 'number',
                'total' => 'sum',
                'sortable' => false,
                'header_css_class' => 'col-orders',
                'column_css_class' => 'col-orders'
            ]
        );

        $this->addColumn(
            'status',
            [
                'header' => __('Status'),
                'index' => 'status'
            ]
        );

        $this->addExportType('*/*/exportSalesCsv', __('CSV'));
        $this->addExportType('*/*/exportSalesExcel', __('Excel XML'));
        return parent::_prepareColumns();
    }
}
