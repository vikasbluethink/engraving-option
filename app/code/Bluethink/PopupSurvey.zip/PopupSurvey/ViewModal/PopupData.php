<?php

namespace Bluethinkinc\PopupSurvey\ViewModal;

use Magento\Framework\View\Element\Template;
use Magento\Widget\Block\BlockInterface;
use Bluethinkinc\PopupSurvey\Model\Config\Provider;
use Magento\Checkout\Model\Session;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\UrlInterface;
use Magento\Catalog\Api\ProductRepositoryInterface;

class PopupData implements \Magento\Framework\View\Element\Block\ArgumentInterface
{
    private $configProvider;

    private $checkoutSession;


    private $storeManager;

    private $productRepository;

    private $productSku;

    public function __construct(
        Provider $configProvider,
        Session $checkoutSession,
        StoreManagerInterface $storeManager,
        ProductRepositoryInterface $productRepository
    ) {
        $this->configProvider = $configProvider;
        $this->checkoutSession = $checkoutSession;
        $this->storeManager = $storeManager;
        $this->productRepository = $productRepository;
    }


    public function getModuleStatus()
    {
        return $this->configProvider->getModuleStatus();
    }

    public function getSurveyProductSku()
    {
        return $this->configProvider->getSurveyProductSku();
    }

    public function getImage()
    {
        $product = $this->productRepository->get($this->getProductSku());
        return $this->getBaseUrl().$product->getData('small_image');
    }

    public function getSurveyUrl()
    {
        return $this->configProvider->getSurveyUrl();
    }

    public function getSurveyText()
    {
        return $this->configProvider->getSurveyText();
    }

    public function getSurveyParagraph()
    {
        return $this->configProvider->getSurveyParagraph();
    }

    public function isProductPurchased()
    {
        if ($this->configProvider->getModuleStatus()) {
            $order  = $this->checkoutSession->getLastRealOrder();
            $surveySku = $this->configProvider->getSurveyProductSku();
            $orderItems = $order->getAllVisibleItems();
            foreach ($orderItems as $item) {
                if (in_array($item->getSku(), $surveySku)) {
                    $this->setProductSku($item->getSku());
                    return true;
                }
            }
            return false;
        }
    }

    public function setProductSku($sku)
    {
        $this->productSku = $sku;
        return $this->productSku;
    }

    public function getProductSku()
    {
        return $this->productSku;
    }

    public function isDateAvailable()
    {
        if ($this->configProvider->getModuleStatus()) {
            $startDate = strtotime($this->configProvider->getSurveyDateTo());
            $endDate = strtotime($this->configProvider->getSurveyDateFrom());
            if ($startDate <= $endDate) {
                return true;
            }
            return false;
        }
    }

    public function getBaseUrl()
    {
        $baseUrl = $this->storeManager->getStore()->getBaseUrl(UrlInterface::URL_TYPE_MEDIA);
        return $baseUrl . "catalog/product";
    }
}
