var config = {
    map: {
        '*': {
            'popup-survey': 'Bluethinkinc_PopupSurvey/js/popup-survey-modal'
        }
    }
};
