require(
    [
        'jquery',
        'Magento_Ui/js/modal/modal'
    ],
    function(
        $,
        modal
    ) {
        // console.log('hello ji ');
        let options = {
            type: 'popup',
            responsive: true,
            innerScroll: true,
            modalClass: 'style-modal',
            buttons: [
                {
                text: $.mage.__("SURE I'LL GIVE FEEDBACK"),
                class: '',
                click: function (data) {
                    window.open(window.valuesConfig, '_blank');
                }
            }, {
                text: $.mage.__('NO THANKS'),
                class: '',
                click: function (data) {
                    this.closeModal();
                }
            }
        ]
        };
        
        
        let $myModal = $('#survey-modal-content');
        let popup = modal(options, $myModal);
        
        function myGreeting() {
            // document.getElementById("demo").innerHTML = "Happy Birthday!"
            $myModal.modal('openModal');
            $myModal.css("display","block");
          }

        setTimeout(myGreeting, 1000);
        //this opens the modal, you can use some click event or whatever you need to trigger the modal here
    }
    );